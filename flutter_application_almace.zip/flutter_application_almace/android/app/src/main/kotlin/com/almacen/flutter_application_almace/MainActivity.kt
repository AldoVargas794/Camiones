package com.almacen.flutter_application_almace

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
