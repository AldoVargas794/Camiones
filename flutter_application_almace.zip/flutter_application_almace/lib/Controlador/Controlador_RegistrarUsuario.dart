import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ControladorRegistrarUsuario {
 final FirebaseAuth _auth = FirebaseAuth.instance;
 final FirebaseFirestore _firestore = FirebaseFirestore.instance;

Future<bool> registrarUsuario(String nombre, String email, String password) async {
 try {
    UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );

    if (userCredential.user != null) {
      // Almacena información adicional del usuario en Firestore
      await _firestore.collection('usuarios').doc(userCredential.user!.uid).set({
        'nombre': nombre,
        'email': email,
        // Puedes agregar más campos según sea necesario
      });

      return true;
    } else {
      print("Error: No se pudo crear el usuario.");
      return false;
    }
 } catch (e) {
    if (e is FirebaseAuthException && e.code == 'email-already-in-use') {
      print("El correo electrónico ya está en uso.");
    } else {
      print("Error al registrar usuario: $e");
    }
    return false;
 }
}

Future<void> agregarUsuarioAdmin() async {
 try {
    // Verifica si ya existe un usuario admin
    QuerySnapshot querySnapshot = await _firestore.collection('usuarios').where('tipoUsuario', isEqualTo: 'admin').get();
    if (querySnapshot.docs.isEmpty) {
      // Si no existe, crea un nuevo usuario admin
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: 'admin@example.com',
        password: 'admin123',
      );

      // Verifica si el usuario admin fue creado correctamente
      if (userCredential.user != null) {
        // Almacena información del usuario admin en Firestore
        await _firestore.collection('usuarios').doc(userCredential.user!.uid).set({
          'nombre': 'admin',
          'email': 'admin@example.com',
          'tipoUsuario': 'admin',
          'esAdmin': true,
        });

        print("Usuario admin agregado");
      } else {
        print("Error: No se pudo crear el usuario admin.");
      }
    }
 } catch (e) {
    print("Error al agregar usuario admin: $e");
 }
}
}