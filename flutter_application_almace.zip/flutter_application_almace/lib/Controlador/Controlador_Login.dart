import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ControladorLogin {
 final FirebaseAuth _auth = FirebaseAuth.instance;

 Future<bool> login(String email, String password) async {
    try {
      // Intenta iniciar sesión con Firebase Authentication
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return true;
    } catch (e) {
      print("Error al iniciar sesión: $e");
      return false;
    }
 }

 Future<bool> isAdmin(String email) async {
    // Asumiendo que tienes una colección en Firestore llamada 'usuarios'
    // donde almacenas información adicional del usuario, incluido si es admin
    final userDoc = await FirebaseFirestore.instance.collection('usuarios').doc(email).get();
    if (userDoc.exists && userDoc.data()?['esAdmin'] == true) {
      return true;
    }
    return false;
 }

 Future<int> getTipoUsuario(String email) async {
    final userDoc = await FirebaseFirestore.instance.collection('usuarios').doc(email).get();
    if (userDoc.exists) {
      final tipoUsuario = userDoc.data()?['tipoUsuario'];
      if (tipoUsuario == 'Almacenista') {
        return 1;
      } else if (tipoUsuario == 'Vigilante') {
        return 2;
      }
    }
    return 0; // No se encontró el usuario
 }
}