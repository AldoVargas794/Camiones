class controladorCamiones {
  
}