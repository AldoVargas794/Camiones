class Almacenobjeto {
 final String nombre;
 final int folio;
 final int cantidad;
 final String marca;
 final String categoria;

 Almacenobjeto({
    required this.nombre,
    required this.folio,
    required this.cantidad,
    required this.marca,
    required this.categoria,
 });
}