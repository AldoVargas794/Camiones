import '../Modelo/Entrada.dart';
import '../Modelo/Salida.dart';

class Agenda {
  DateTime fechaActual;
  List<EntradaProgramada> entradasProgramadas;
  List<SalidaProgramada> salidasProgramadas;

  Agenda({
    required this.fechaActual,
    required this.entradasProgramadas,
    required this.salidasProgramadas,
  });
}


