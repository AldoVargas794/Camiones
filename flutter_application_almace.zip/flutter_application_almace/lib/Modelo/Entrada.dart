class EntradaProgramada {
  String matriculaCamion;
  String horaEntrada;

  EntradaProgramada({
    required this.matriculaCamion,
    required this.horaEntrada,
  });
}
