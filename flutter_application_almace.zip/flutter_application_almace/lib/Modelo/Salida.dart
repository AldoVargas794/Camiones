class SalidaProgramada {
  String matriculaCamion;
  String horaSalida;

  SalidaProgramada({
    required this.matriculaCamion,
    required this.horaSalida,
  });
}