import 'Controlador/Controlador_Login.dart';
import 'package:flutter/material.dart';
import 'Vista/Vista_registrar.dart';
import 'Vista/Vista_MenuAlmacen.dart';
import 'Vista/Vista_MenuVigilante.dart';
import 'package:firebase_core/firebase_core.dart';
//import 'firebase_options.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
 WidgetsFlutterBinding.ensureInitialized();
 await Firebase.initializeApp(
    options: FirebaseOptions(
        apiKey: "AIzaSyDkvtNVNLzz9Wpgpya4kkTjN_2aCFcOqck", // Tu clave API
         authDomain: "almacen-camion.firebaseapp.com", // Reemplaza con tu authDomain
         databaseURL: "https://almacen-camion.firebaseio.com", // Reemplaza con tu databaseURL
         projectId: "almacen-camion", // Tu projectId
         storageBucket: "almacen-camion.appspot.com", // Tu storageBucket
         messagingSenderId: "752418063958", // Reemplaza con tu messagingSenderId
         appId: "1:752418063958:android:0e4cb2aaaf1fcab12f9df7", // Reemplaza con tu appId
         measurementId: "G-XXXXXXXXXX", // Reemplaza con tu measurementId si lo tienes
    ),
 );
 runApp(MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Tu Aplicacion",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        bottomSheetTheme: const BottomSheetThemeData(
            backgroundColor: Color.fromARGB(255, 232, 114, 4), elevation: 0.0),
        colorScheme:
            ColorScheme.fromSeed(seedColor: const Color.fromARGB(0, 0, 0, 0)),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  ControladorLogin controlador = ControladorLogin();
  String _email = '';
  String _password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 70, 209, 191),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: 20),
                const Icon(
                  Icons.local_shipping,
                  size: 100,
                  color: Colors.white,
                ),
                const SizedBox(height: 50.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      child: ElevatedButton(
                                onPressed: () async { // Añade 'async' para poder usar 'await'
                                  bool? loginResult = await controlador.login(_email, _password); // Espera a que se resuelva el Future
                                  if (loginResult == true) { // Verifica si el resultado es true
                                  int? userType = await controlador.getTipoUsuario(_email); // Asume que getTipoUsuario también devuelve un Future<int?>
                                      if (userType == 1) {
                                          Navigator.of(context, rootNavigator: true).push(
                                          MaterialPageRoute(
                                          builder: (context) => const Inicio(),
                                      ),
                                );
                                  } else {
                                        Navigator.of(context, rootNavigator: true).push(
                                        MaterialPageRoute(
                                        builder: (context) => const AlmacenesMenu(),
                                       ),
                                  );
                                 }
                                 } else {
                                   // Maneja el caso en que el login falla o el resultado es null
                                  print("Error: No se pudo iniciar sesión.");
                                     }
                                 },
                                   style: ButtonStyle(
                                  backgroundColor: MaterialStateProperty.all(Colors.transparent),
                                  elevation: MaterialStateProperty.all(0),
                                  ),
                                child: const Text(
                                'INGRESAR',
                                style: TextStyle(color: Colors.white, fontSize: 20),
                                ),
                          ),
                    ),
                    Container(
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context, rootNavigator: true).push(
                            MaterialPageRoute(
                              builder: (context) => const RegistroUsuarios(),
                            ),
                          );
                        },
                        style: ButtonStyle(
                          backgroundColor:
                              MaterialStateProperty.all(Colors.transparent),
                          elevation: MaterialStateProperty.all(0),
                        ),
                        child: const Text(
                          'REGISTRARSE',
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Center(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(height: 40),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.7,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: TextFormField(
                            keyboardType: TextInputType.emailAddress,
                            decoration: const InputDecoration(
                              hintText: 'Usuario',
                              hintStyle: TextStyle(
                                  color: Color.fromARGB(255, 70, 209, 191),
                                  fontSize: 17),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(horizontal: 20),
                            ),
                            style: const TextStyle(
                                color: Color.fromARGB(255, 0, 0, 0)),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Introduce aquí tu usuario';
                              }
                              return null;
                            },
                            onChanged: (value) {
                              setState(() {
                                _email = value;
                              });
                            },
                          ),
                        ),
                        const SizedBox(height: 20.0),
                        Container(
                          width: MediaQuery.of(context).size.width * 0.7,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: TextFormField(
                            obscureText: true,
                            decoration: const InputDecoration(
                              hintText: 'Contraseña',
                              hintStyle: TextStyle(
                                  color: Color.fromARGB(255, 70, 209, 191),
                                  fontSize: 17),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(horizontal: 20),
                            ),
                            style: const TextStyle(color: Colors.black),
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Ingrese su contraseña';
                              }
                              return null;
                            },
                            onChanged: (value) {
                              setState(() {
                                _password = value;
                              });
                            },
                          ),
                        ),
                        const SizedBox(height: 25.0),
                        const SizedBox(height: 16.0),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
