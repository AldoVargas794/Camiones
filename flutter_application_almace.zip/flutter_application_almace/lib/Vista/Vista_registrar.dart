import '../Controlador/Controlador_RegistrarUsuario.dart';
import 'package:flutter/material.dart';
//import '../Modelo/Usuario.dart';
class RegistroUsuarios extends StatefulWidget {
  const RegistroUsuarios({Key? key}) : super(key: key);

  @override
  _RegistroUsuariosState createState() => _RegistroUsuariosState();
}

class _RegistroUsuariosState extends State<RegistroUsuarios> {
  String nombre = '';
  String contrasena = '';
  String matricula = '';
  String? tipoUsuario; // Cambiado a String nulable
  bool esAdmin = false;
  String adminNombre = 'admin';
  String adminContrasena = 'admin123';
  bool adminValido = false;
  ControladorRegistrarUsuario _controlador = ControladorRegistrarUsuario();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registro de Usuarios'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Ingrese el nombre de usuario y contraseña de un usuario administrador:'),
              TextField(
                decoration: const InputDecoration(labelText: 'Nombre de Usuario'),
                onChanged: (value) {
                  setState(() {
                    nombre = value;
                  });
                },
              ),
              TextField(
                decoration: const InputDecoration(labelText: 'Contraseña'),
                onChanged: (value) {
                  setState(() {
                    contrasena = value;
                  });
                },
              ),
              ElevatedButton(
                onPressed: () {
                  if (nombre == adminNombre && contrasena == adminContrasena) {
                    setState(() {
                      adminValido = true;
                    });
                  } else {
                    setState(() {
                      adminValido = false;
                    });
                  }
                },
                child: const Text('Verificar'),
              ),
              adminValido
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Ingrese los datos del nuevo usuario:'),
                        TextField(
                          decoration: const InputDecoration(labelText: 'Nombre'),
                          onChanged: (value) {
                            setState(() {
                              matricula = value;
                            });
                          },
                        ),
                        TextField(
                          decoration: const InputDecoration(labelText: 'Contraseña'),
                          onChanged: (value) {
                            setState(() {
                              contrasena = value;
                            });
                          },
                        ),
                        DropdownButtonFormField<String>(
                          value: tipoUsuario,
                          items: ['Almacenista', 'Vigilante']
                              .map((label) => DropdownMenuItem(
                                    value: label,
                                    child: Text(label),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            setState(() {
                              tipoUsuario = value; // Asignar el valor seleccionado
                            });
                          },
                          decoration: const InputDecoration(labelText: 'Tipo de Usuario'),
                        ),
ElevatedButton(
 onPressed: () async { // Asegúrate de que la función onPressed sea async
    // Extract values from the Usuario object
    String nombre = matricula;
    String email = matricula; // Assuming matricula is used as email, adjust as necessary
    String password = contrasena;

    // Call registrarUsuario with the correct arguments
    bool registrado = await _controlador.registrarUsuario(nombre, email, password); // Usa await aquí

    if (registrado) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Usuario Registrado'),
          content: Text('Nombre: $matricula\nContraseña: $contrasena\nTipo de Usuario: $tipoUsuario'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cerrar'),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('El usuario ya existe')));
    }
 },
 child: const Text('Registrar'),
),
                      ],
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }
}




